// src/service-worker.ts
var BASE = "https://shoplit.in";
async function getToken() {
  const v = await chrome.storage.local.get("token");
  return v.token || null;
}
async function api(path, init) {
  const token = await getToken();
  if (!token) throw new Error("unauthorized");
  const res = await fetch(BASE + path, {
    ...init,
    headers: {
      ...init?.headers ?? {},
      Authorization: `Bearer ${token}`,
      ...init?.body ? { "Content-Type": "application/json" } : {}
    }
  });
  if (res.status === 401) throw new Error("unauthorized");
  if (!res.ok) throw new Error(`${path} \u2192 ${res.status}`);
  if (res.status === 204) return void 0;
  return await res.json();
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg?.type === "listCarts") {
        const carts = await api("/api/v1/carts");
        sendResponse({ ok: true, data: carts.map((c) => ({ id: c.id, title: c.title })) });
      } else if (msg?.type === "addProduct") {
        await api(`/api/v1/carts/${msg.cartId}/items`, {
          method: "POST",
          body: JSON.stringify(msg.body)
        });
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: "unknown message" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "shoplit-token" && typeof msg.token === "string") {
    chrome.storage.local.set({ token: msg.token }, () => sendResponse({ ok: true }));
    return true;
  }
  sendResponse({ ok: false });
  return false;
});
