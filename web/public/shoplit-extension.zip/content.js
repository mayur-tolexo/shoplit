// src/retailer.ts
function retailerFromUrl(raw) {
  let host = "";
  try {
    host = new URL(raw).hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return "other";
  }
  if (host === "amzn.in") return "amazon.in";
  if (host === "amzn.to" || host === "a.co") return "amazon.com";
  if (host.endsWith("nykaa.com")) return "nykaa.com";
  if (host.endsWith("amazon.in")) return "amazon.in";
  if (host.endsWith("amazon.com")) return "amazon.com";
  if (host.endsWith("myntra.com")) return "myntra.com";
  if (host.endsWith("flipkart.com")) return "flipkart.com";
  if (host.endsWith("ajio.com")) return "ajio.com";
  return "other";
}

// src/extract.ts
function canonicalUrl(doc) {
  const link = doc.querySelector('link[rel="canonical"]')?.getAttribute("href");
  const ogUrl = meta(doc, "og:url");
  return link || ogUrl || doc.location?.href || "";
}
function meta(doc, prop) {
  const el = doc.querySelector(`meta[property="${prop}"]`) || doc.querySelector(`meta[name="${prop}"]`);
  return el?.getAttribute("content")?.trim() || "";
}
function isProductPage(doc) {
  for (const b of Array.from(doc.querySelectorAll('script[type="application/ld+json"]'))) {
    try {
      const data = JSON.parse(b.textContent || "");
      const items = Array.isArray(data) ? data : data["@graph"] ? data["@graph"] : [data];
      for (const it of items) {
        const t = it && it["@type"];
        if (t === "Product" || Array.isArray(t) && t.includes("Product")) return true;
      }
    } catch {
    }
  }
  if (meta(doc, "og:type").toLowerCase().includes("product")) return true;
  const url = doc.location?.href || "";
  return /\/dp\/|\/p\/[^/]|\/buy(\/|\?|#|$)|\/\d+\/buy/.test(url);
}
function priceStr(amount) {
  if (amount === void 0 || amount === null || `${amount}` === "") return "";
  const n = `${amount}`.replace(/[^\d.]/g, "");
  return n ? `\u20B9${n}` : "";
}
function fromJsonLd(doc, canonical) {
  const blocks = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
  const products = [];
  for (const b of blocks) {
    try {
      const data = JSON.parse(b.textContent || "");
      const items = Array.isArray(data) ? data : data["@graph"] ? data["@graph"] : [data];
      for (const it of items) {
        const t = it && it["@type"];
        if (t === "Product" || Array.isArray(t) && t.includes("Product")) products.push(it);
      }
    } catch {
    }
  }
  if (!products.length) return null;
  const p = products.find((x) => x.url && canonical && x.url === canonical) || products[0];
  const image = Array.isArray(p.image) ? p.image[0] : p.image;
  const offers = Array.isArray(p.offers) ? p.offers[0] : p.offers;
  return {
    title: typeof p.name === "string" ? p.name.trim() : "",
    imageUrl: typeof image === "string" ? image : "",
    priceText: priceStr(offers?.price)
  };
}
function extractProduct(doc) {
  const url = canonicalUrl(doc);
  const retailer = retailerFromUrl(url);
  const jsonld = fromJsonLd(doc, url) ?? {};
  const title = jsonld.title || meta(doc, "og:title") || meta(doc, "twitter:title") || doc.title.trim();
  const imageUrl = jsonld.imageUrl || meta(doc, "og:image") || meta(doc, "twitter:image");
  const priceText = jsonld.priceText || priceStr(meta(doc, "product:price:amount"));
  if (!title && !imageUrl) return null;
  return { title, imageUrl: imageUrl || "", priceText, url, retailer };
}

// src/api.ts
function send(msg) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(msg, (resp) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!resp?.ok) return reject(new Error(resp?.error || "error"));
      resolve(resp.data);
    });
  });
}
async function listCarts() {
  return send({ type: "listCarts" });
}
async function addProduct(cartId, p, note) {
  await send({
    type: "addProduct",
    cartId,
    body: {
      title: p.title,
      image_url: p.imageUrl,
      price_text: p.priceText,
      original_url: p.url,
      retailer: p.retailer,
      note
    }
  });
}

// src/add-ui.ts
var STYLE_ID = "sl-styles";
var CSS = `
@keyframes sl-in { from { opacity:0; transform: translateY(10px) scale(.98); } to { opacity:1; transform:none; } }
@keyframes sl-spin { to { transform: rotate(360deg); } }
@keyframes sl-pop { 0%{transform:scale(0);} 55%{transform:scale(1.18);} 100%{transform:scale(1);} }
@keyframes sl-fade { from { opacity:0; } to { opacity:1; } }
.sl-root { animation: sl-in .24s cubic-bezier(.2,.7,.3,1); font: 14px/1.45 system-ui, -apple-system, sans-serif; color:#1a1a1a; }
.sl-bar { display:flex; align-items:center; justify-content:space-between; padding:11px 14px; border-bottom:1px solid #ece5d8; background:#fbf7f0; border-radius:12px 12px 0 0; }
.sl-logo { display:inline-flex; align-items:center; gap:7px; font-weight:700; font-size:14px; color:#1a1a1a; letter-spacing:-.01em; }
.sl-logo svg { width:18px; height:18px; }
.sl-x { background:none; border:0; font-size:17px; line-height:1; color:#8a8a8a; cursor:pointer; padding:3px 7px; border-radius:7px; transition:background .15s, color .15s; }
.sl-x:hover { background:rgba(0,0,0,.06); color:#1a1a1a; }
.sl-pad { padding:14px; display:flex; flex-direction:column; gap:10px; }
.sl-head { display:flex; gap:11px; align-items:flex-start; }
.sl-thumb { width:56px; height:56px; object-fit:cover; border-radius:10px; background:#ece7de; flex:none; }
.sl-input { width:100%; box-sizing:border-box; padding:8px 10px; border:1px solid #d9d2c5; border-radius:9px; font:inherit; background:#fff; transition:border-color .15s, box-shadow .15s; }
.sl-input:focus { outline:none; border-color:#B5532A; box-shadow:0 0 0 3px rgba(181,83,42,.16); }
.sl-title-in { font-weight:600; }
.sl-btn { display:inline-flex; align-items:center; justify-content:center; gap:7px; padding:10px; border:0; border-radius:999px; background:#1a1a1a; color:#fbf7f0; font:inherit; font-weight:600; cursor:pointer; transition:transform .12s ease, opacity .15s, box-shadow .2s; }
.sl-btn:hover { transform:translateY(-1px); }
.sl-btn:active { transform:translateY(0); }
.sl-btn[disabled] { opacity:.75; cursor:default; transform:none; }
.sl-btn-accent { background:linear-gradient(135deg,#C2410C,#9A3412); box-shadow:0 3px 12px rgba(154,52,18,.3); }
.sl-spinner { width:15px; height:15px; border:2px solid rgba(255,255,255,.45); border-top-color:#fff; border-radius:50%; animation:sl-spin .7s linear infinite; }
.sl-msg { margin:0; font-size:12px; color:#6b6b6b; min-height:1em; }
.sl-success { display:flex; flex-direction:column; align-items:center; gap:10px; padding:30px 18px; text-align:center; }
.sl-check { width:56px; height:56px; border-radius:50%; background:#1f9d55; color:#fff; display:grid; place-items:center; font-size:30px; line-height:1; animation:sl-pop .42s cubic-bezier(.2,.8,.3,1.25); }
.sl-success strong { font-size:16px; }
.sl-sub { color:#6b6b6b; font-size:13px; animation:sl-fade .3s .15s both; }
`;
var MARK = `<svg viewBox="0 0 64 64" aria-hidden><rect width="64" height="64" rx="14" fill="#B5532A"/><path d="M24 28 a8 8 0 0 1 16 0" fill="none" stroke="#F4EBDD" stroke-width="3.6" stroke-linecap="round"/><path d="M18.5 27 h27 l2 19.2 a4.5 4.5 0 0 1-4.5 5 H21 a4.5 4.5 0 0 1-4.5-5 z" fill="#F4EBDD"/></svg>`;
function ensureStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const s = document.createElement("style");
  s.id = STYLE_ID;
  s.textContent = CSS;
  (document.head || document.documentElement).appendChild(s);
}
async function getToken() {
  return new Promise(
    (resolve) => chrome.storage.local.get("token", (v) => resolve(v.token || null))
  );
}
async function renderAddUI(opts) {
  const { root, product, onConnectNeeded, onClose, onAdded } = opts;
  ensureStyles();
  const paint = (inner) => {
    root.innerHTML = `<div class="sl-root"><div class="sl-bar"><span class="sl-logo">${MARK}shoplit</span>` + (onClose ? `<button class="sl-x" aria-label="Close">\u2715</button>` : ``) + `</div>${inner}</div>`;
    if (onClose) root.querySelector(".sl-x").onclick = onClose;
  };
  const $ = (s) => root.querySelector(s);
  const token = await getToken();
  if (!token) {
    paint(`<div class="sl-pad">
      <p style="margin:0">Connect the extension to your shoplit account.</p>
      <button id="sl-connect" class="sl-btn sl-btn-accent">Connect shoplit account</button>
      <p class="sl-msg">Already opened the connect page? Paste the code:</p>
      <input id="sl-code" class="sl-input" placeholder="Paste connection code" />
      <button id="sl-save-code" class="sl-btn">Connect</button>
    </div>`);
    $("#sl-connect").onclick = onConnectNeeded;
    $("#sl-save-code").onclick = () => {
      const code = $("#sl-code").value.trim();
      if (!code) return;
      chrome.storage.local.set({ token: code }, () => renderAddUI(opts));
    };
    return;
  }
  if (!product) {
    paint(`<div class="sl-pad"><p style="margin:0">Couldn't find a product on this page. Open a product page and try again.</p></div>`);
    return;
  }
  let carts = [];
  try {
    carts = await listCarts();
  } catch (e) {
    if (e.message === "unauthorized") return onConnectNeeded();
    paint(`<div class="sl-pad"><p style="margin:0">Couldn't load your carts. Try again.</p></div>`);
    return;
  }
  const options = carts.map((c) => `<option value="${escapeAttr(c.id)}">${escapeHtml(c.title)}</option>`).join("");
  paint(`<div class="sl-pad">
      <div class="sl-head">
        <img src="${escapeAttr(product.imageUrl)}" class="sl-thumb" alt=""/>
        <input id="sl-title" class="sl-input sl-title-in" value="${escapeAttr(product.title)}"/>
      </div>
      <input id="sl-price" class="sl-input" value="${escapeAttr(product.priceText)}" placeholder="\u20B9 price"/>
      <input id="sl-image" class="sl-input" value="${escapeAttr(product.imageUrl)}" placeholder="Image URL"/>
      <input id="sl-url" class="sl-input" value="${escapeAttr(product.url)}" placeholder="Product / affiliate link"/>
      <select id="sl-cart" class="sl-input">${options}</select>
      <input id="sl-note" class="sl-input" placeholder="Note (optional)"/>
      <button id="sl-add" class="sl-btn sl-btn-accent">\uFF0B Add to cart</button>
      <p id="sl-msg" class="sl-msg"></p>
    </div>`);
  $("#sl-add").onclick = async () => {
    const btn = $("#sl-add");
    btn.disabled = true;
    btn.innerHTML = `<span class="sl-spinner"></span>Adding\u2026`;
    const cartSel = $("#sl-cart");
    const cartName = cartSel.options[cartSel.selectedIndex]?.text ?? "your cart";
    try {
      await addProduct(
        cartSel.value,
        {
          ...product,
          title: $("#sl-title").value.trim(),
          priceText: $("#sl-price").value.trim(),
          imageUrl: $("#sl-image").value.trim(),
          // Creator can paste their own affiliate/short link → redirect target.
          url: $("#sl-url").value.trim() || product.url
        },
        $("#sl-note").value.trim()
      );
      paint(`<div class="sl-success">
        <div class="sl-check">\u2713</div>
        <div><strong>Added!</strong></div>
        <div class="sl-sub">Saved to ${escapeHtml(cartName)}</div>
      </div>`);
      if (onAdded) setTimeout(onAdded, 1400);
    } catch (e) {
      if (e.message === "unauthorized") return onConnectNeeded();
      btn.disabled = false;
      btn.textContent = "\uFF0B Add to cart";
      $("#sl-msg").textContent = "Couldn't add \u2014 try again.";
    }
  };
}
function escapeHtml(s) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
}
function escapeAttr(s) {
  return escapeHtml(s).replace(/"/g, "&quot;");
}

// src/content.ts
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "extract") {
    sendResponse({ type: "extracted", product: extractProduct(document) });
  }
  return false;
});
var BTN_ID = "sl-add-btn";
var BTN_STYLE_ID = "sl-btn-styles";
var BTN_MARK = `<svg viewBox="0 0 64 64" width="17" height="17" aria-hidden style="flex:none"><path d="M24 28 a8 8 0 0 1 16 0" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M18.5 27 h27 l2 19.2 a4.5 4.5 0 0 1-4.5 5 H21 a4.5 4.5 0 0 1-4.5-5 z" fill="#fff"/></svg>`;
function ensureButtonStyles() {
  if (document.getElementById(BTN_STYLE_ID)) return;
  const s = document.createElement("style");
  s.id = BTN_STYLE_ID;
  s.textContent = `
    @keyframes sl-btn-in { from{opacity:0;transform:translateY(6px) scale(.96)} to{opacity:1;transform:none} }
    .sl-fab-btn { display:inline-flex; align-items:center; gap:8px; background:linear-gradient(135deg,#C2410C,#9A3412); color:#fff; border:0; border-radius:999px; padding:10px 18px; font:600 14px/1 system-ui,-apple-system,sans-serif; cursor:pointer; box-shadow:0 4px 14px rgba(154,52,18,.35); transition:transform .16s ease, box-shadow .16s ease; animation:sl-btn-in .26s ease both; }
    .sl-fab-btn:hover { transform:translateY(-2px); box-shadow:0 9px 24px rgba(154,52,18,.45); }
    .sl-fab-btn:active { transform:translateY(0); }`;
  (document.head || document.documentElement).appendChild(s);
}
function injectButton() {
  if (document.getElementById(BTN_ID)) return;
  if (!isProductPage(document)) return;
  const product = extractProduct(document);
  if (!product) return;
  ensureButtonStyles();
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "sl-fab-btn";
  btn.innerHTML = `${BTN_MARK}<span>Add to shoplit</span>`;
  btn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    togglePanel(product);
  };
  const title = visibleTitle();
  if (title) {
    const wrap = document.createElement("div");
    wrap.id = BTN_ID;
    wrap.style.cssText = "width:100%;margin:12px 0;display:block;";
    wrap.appendChild(btn);
    title.insertAdjacentElement("afterend", wrap);
  } else {
    btn.id = BTN_ID;
    Object.assign(btn.style, { position: "fixed", left: "18px", bottom: "18px", zIndex: "2147483647" });
    document.body.appendChild(btn);
  }
}
function visibleTitle() {
  const heads = Array.from(document.querySelectorAll("h1"));
  return heads.find((h) => h.offsetParent !== null && (h.textContent ?? "").trim().length > 3) ?? null;
}
function togglePanel(product) {
  const existing = document.getElementById("sl-panel");
  if (existing) {
    existing.remove();
    return;
  }
  const panel = document.createElement("div");
  panel.id = "sl-panel";
  Object.assign(panel.style, {
    position: "fixed",
    right: "18px",
    top: "84px",
    zIndex: "2147483647",
    width: "320px",
    maxHeight: "80vh",
    overflow: "auto",
    background: "#fbf7f0",
    color: "#1a1a1a",
    border: "1px solid #d9d2c5",
    borderRadius: "12px",
    boxShadow: "0 8px 28px rgba(0,0,0,.25)"
  });
  document.body.appendChild(panel);
  renderAddUI({
    root: panel,
    product,
    onConnectNeeded: () => window.open("https://shoplit.in/connect-extension", "_blank"),
    onClose: () => panel.remove(),
    onAdded: () => panel.remove()
  });
}
injectButton();
var obs = new MutationObserver(() => injectButton());
obs.observe(document.documentElement, { childList: true, subtree: true });
